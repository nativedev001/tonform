// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyB3Gyf05ESUL5N2QPdEEpbn0mnhsSar830",
  authDomain: "launchpad-4689d.firebaseapp.com",
  projectId: "launchpad-4689d",
  storageBucket: "launchpad-4689d.firebasestorage.app",
  messagingSenderId: "1030261968923",
  appId: "1:1030261968923:web:e55949696e859da99ca8be",
  measurementId: "G-4MHR72XKCN"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
